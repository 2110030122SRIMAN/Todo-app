const express = require("express");
const router = express.Router();
const ToDo = require("../models/ToDo");

// Get all To-Do items
router.get("/", async (req, res) => {
  try {
    const todos = await ToDo.find();
    res.json(todos);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Add a new To-Do item
router.post("/", async (req, res) => {
  const todo = new ToDo({
    text: req.body.text,
  });

  try {
    const newToDo = await todo.save();
    res.status(201).json(newToDo);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete a To-Do item
router.delete("/:id", async (req, res) => {
  try {
    await ToDo.findByIdAndDelete(req.params.id);
    res.json({ message: "Deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
